"""
Aptura Tech Solutions - Python Development Internship (Batch 02)
Week 02 Task - Library Management System (Advanced Version)

Author: Hafiz Siddiqui

Run with:
    python3 main.py
"""

from library_system.cli import run

if __name__ == "__main__":
    run()
