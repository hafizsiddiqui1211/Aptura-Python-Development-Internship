# Library Management System (Advanced Version)
Aptura Tech Solutions — Python Development Internship, Batch 02, Week 02 Task
Author: Hafiz Siddiqui

## Requirements
Python 3.8+ only. No third-party packages — everything used
(`sqlite3`, `hashlib`, `logging`, `datetime`) is in the Python standard
library, so there is nothing to `pip install`.

## How to run
```
python3 main.py
```

On first run there will be no librarian accounts yet, so the program will
walk you through creating the first admin account, then log you in.

A SQLite database file `library.db` and a log file `library.log` will be
created in this folder automatically the first time you run it.

## Project layout
```
main.py                          entry point
library_system/
    __init__.py
    exceptions.py                custom exception hierarchy
    logger_setup.py              logging configuration (writes to library.log)
    database.py                  SQLite connection, schema, atomic transactions
    auth.py                      librarian registration/login (PBKDF2 password hashing)
    services.py                  core business logic (books, members, issue/return, fines, search)
    cli.py                       menu-driven interface
bonus_concurrency_test.py        optional: stress-tests the atomic issue-book guard
                                  with 10 concurrent processes racing for the last
                                  copy of a book (see Question 01 in the report)
```

## Running the bonus concurrency test
```
python3 bonus_concurrency_test.py
```
This resets `library.db`, seeds one book with a single copy, then spawns 10
separate processes that all try to issue it at once. It prints how many
succeeded (should be exactly 1) and confirms `available_copies` never goes
negative.

## Default loan terms
- Loan period: 14 days
- Fine: Rs. 10 per day overdue

Both are constants at the top of `library_system/services.py` if you want
to change them.

## Documentation
See `Week_02_Task_Report.pdf` for the full write-up: system architecture,
the two high-level design questions (multi-librarian concurrency and
storage-technology comparison), the project flow diagram, and execution
screenshots.
