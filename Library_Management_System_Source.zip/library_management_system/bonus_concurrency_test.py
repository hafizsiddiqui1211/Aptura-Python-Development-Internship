"""
Bonus / supplementary test (not part of the core CLI deliverable).

Empirically verifies the claim made in Question 01 of the report: that the
atomic `UPDATE ... WHERE available_copies > 0` guard in
`LibraryService.issue_book` prevents overselling even when many librarians
hit the same book at effectively the same instant.

Simulates 10 separate "librarian" processes all trying to issue the SAME
book, which has only 1 copy, at the same time. Exactly one should succeed;
the other nine should cleanly receive BookUnavailableError; and the final
available_copies must be 0 -- never negative.

Run with:  python3 bonus_concurrency_test.py
"""

import multiprocessing
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from library_system.database import Database
from library_system.services import LibraryService
from library_system.exceptions import BookUnavailableError


def _attempt_issue(isbn, member_id, worker_id, result_queue):
    db = Database()
    service = LibraryService(db)
    try:
        txn_id, due_date = service.issue_book(isbn, member_id, f"librarian_{worker_id}")
        result_queue.put(("SUCCESS", worker_id, txn_id))
    except BookUnavailableError:
        result_queue.put(("BLOCKED", worker_id, None))
    except Exception as e:  # noqa
        result_queue.put(("UNEXPECTED_ERROR", worker_id, str(e)))
    finally:
        db.close()


def main():
    db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "library.db")
    for ext in ("", "-shm", "-wal"):
        p = db_path + ext
        if os.path.exists(p):
            os.remove(p)

    db = Database()
    service = LibraryService(db)
    service.add_book("999-TEST-0001", "The Last Copy", "Test Author", "Test", total_copies=1)
    service.add_member("Concurrency Tester", "n/a")
    db.close()

    NUM_WORKERS = 10
    result_queue = multiprocessing.Queue()
    processes = [
        multiprocessing.Process(target=_attempt_issue, args=("999-TEST-0001", 1, i, result_queue))
        for i in range(NUM_WORKERS)
    ]

    for p in processes:
        p.start()
    for p in processes:
        p.join()

    results = [result_queue.get() for _ in range(NUM_WORKERS)]
    successes = [r for r in results if r[0] == "SUCCESS"]
    blocked = [r for r in results if r[0] == "BLOCKED"]
    unexpected = [r for r in results if r[0] == "UNEXPECTED_ERROR"]

    db = Database()
    final_row = db.query("SELECT available_copies FROM books WHERE isbn = ?;", ("999-TEST-0001",))[0]
    db.close()

    print(f"Workers that attempted to issue the SAME single copy: {NUM_WORKERS}")
    print(f"  Succeeded : {len(successes)}  (expected: 1)")
    print(f"  Blocked   : {len(blocked)}  (expected: {NUM_WORKERS - 1})")
    print(f"  Unexpected errors: {len(unexpected)}  (expected: 0) -> {unexpected}")
    print(f"Final available_copies in DB: {final_row['available_copies']}  (expected: 0, NEVER negative)")

    ok = len(successes) == 1 and len(blocked) == NUM_WORKERS - 1 and final_row["available_copies"] == 0
    print("\nRESULT:", "PASS -- no overselling occurred." if ok else "FAIL -- data inconsistency detected!")


if __name__ == "__main__":
    main()
