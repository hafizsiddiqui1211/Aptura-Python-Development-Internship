"""Library Management System (Advanced Version) - core package."""
