"""
Menu-driven command-line interface for the Library Management System.

Every action is wrapped in its own try/except so that one bad input or one
business-rule violation (book unavailable, duplicate ISBN, etc.) never
crashes the whole session -- the librarian just sees a clear message and
returns to the menu. All of it is logged via logger_setup.
"""

import sqlite3

from .auth import AuthManager
from .database import Database
from .exceptions import LibraryError
from .logger_setup import get_logger
from .services import LibraryService

logger = get_logger(__name__)


# --------------------------------------------------------------- helpers ---
def _print_table(rows, columns=None):
    if not rows:
        print("[INFO] No records to display.")
        return

    columns = columns or rows[0].keys()
    widths = {
        c: max(len(c), max(len(str(r[c])) for r in rows)) + 2 for c in columns
    }

    header = "".join(c.ljust(widths[c]) for c in columns)
    print(header)
    print("-" * len(header))
    for r in rows:
        print("".join(str(r[c]).ljust(widths[c]) for c in columns))


def _prompt_int(prompt: str):
    while True:
        raw = input(prompt).strip()
        try:
            return int(raw)
        except ValueError:
            print("[ERROR] Please enter a whole number.")


def _prompt_nonempty(prompt: str):
    while True:
        val = input(prompt).strip()
        if val:
            return val
        print("[ERROR] This field cannot be empty.")


# ------------------------------------------------------------- auth flow ---
def _bootstrap_first_admin(auth: AuthManager):
    print("\nNo librarian accounts exist yet -- let's create the first one.")
    while True:
        username = _prompt_nonempty("Choose an admin username: ")
        password = _prompt_nonempty("Choose a password (min 6 characters): ")
        try:
            auth.register(username, password, role="admin")
            print(f"[SUCCESS] Admin account '{username}' created. Please log in.\n")
            return
        except LibraryError as e:
            print(f"[ERROR] {e}")


def _login_screen(auth: AuthManager):
    if not auth.has_any_users():
        _bootstrap_first_admin(auth)

    while True:
        print("\n===== LIBRARY MANAGEMENT SYSTEM =====")
        print("1. Login")
        print("2. Register New Librarian")
        print("3. Exit")
        choice = input("Enter your choice (1-3): ").strip()

        if choice == "1":
            username = input("Username: ").strip()
            password = input("Password: ").strip()
            try:
                return auth.login(username, password)
            except LibraryError as e:
                print(f"[ERROR] {e}")
        elif choice == "2":
            username = _prompt_nonempty("Choose a username: ")
            password = _prompt_nonempty("Choose a password (min 6 characters): ")
            try:
                auth.register(username, password)
                print(f"[SUCCESS] Account '{username}' registered. You can now log in.")
            except LibraryError as e:
                print(f"[ERROR] {e}")
        elif choice == "3":
            return None
        else:
            print("[ERROR] Invalid choice.")


# ------------------------------------------------------------- main menu ---
MAIN_MENU = """
===== LIBRARY MANAGEMENT SYSTEM (logged in as: {user}) =====
 1. Add Book
 2. Add Member
 3. Issue Book
 4. Return Book
 5. Search Books
 6. View Available Books
 7. Filter Books by Category
 8. View All Books
 9. View All Members
10. View Active Issues
11. View Overdue Books & Fines
12. Logout
13. Exit
=============================================================="""


def _run_main_menu(service: LibraryService, username: str):
    while True:
        print(MAIN_MENU.format(user=username))
        choice = input("Enter your choice (1-13): ").strip()

        try:
            if choice == "1":
                _add_book(service)
            elif choice == "2":
                _add_member(service)
            elif choice == "3":
                _issue_book(service, username)
            elif choice == "4":
                _return_book(service, username)
            elif choice == "5":
                keyword = input("Search keyword (title/author/category/ISBN): ")
                _print_table(service.search_books(keyword))
            elif choice == "6":
                _print_table(service.filter_available_books())
            elif choice == "7":
                category = input("Category to filter by: ")
                _print_table(service.filter_by_category(category))
            elif choice == "8":
                _print_table(service.list_all_books())
            elif choice == "9":
                _print_table(service.list_all_members())
            elif choice == "10":
                _print_table(service.list_active_transactions())
            elif choice == "11":
                _view_overdue(service)
            elif choice == "12":
                print(f"[INFO] Logging out '{username}'.")
                logger.info("Librarian '%s' logged out.", username)
                return "LOGOUT"
            elif choice == "13":
                print("[INFO] Exiting the system. Goodbye!")
                return "EXIT"
            else:
                print("[ERROR] Invalid choice. Please enter a number between 1 and 13.")
        except LibraryError as e:
            # Every expected business-rule / validation failure lands here
            print(f"[ERROR] {e}")
        except sqlite3.Error as e:
            # Unexpected database-level failure -- logged with full detail,
            # shown to the user in a friendly, non-technical way.
            logger.exception("Unhandled database error: %s", e)
            print("[ERROR] A database error occurred. Please check library.log and try again.")
        except Exception as e:  # last-resort safety net so the CLI never crashes
            logger.exception("Unexpected error: %s", e)
            print(f"[ERROR] An unexpected error occurred: {e}")


def _add_book(service: LibraryService):
    print("\n--- ADD BOOK ---")
    isbn = _prompt_nonempty("ISBN: ")
    title = _prompt_nonempty("Title: ")
    author = _prompt_nonempty("Author: ")
    category = _prompt_nonempty("Category: ")
    copies = _prompt_int("Total Copies: ")
    service.add_book(isbn, title, author, category, copies)
    print(f"[SUCCESS] '{title}' added with {copies} copies.")


def _add_member(service: LibraryService):
    print("\n--- ADD MEMBER ---")
    name = _prompt_nonempty("Member Name: ")
    contact = input("Contact (phone/email, optional): ").strip()
    service.add_member(name, contact)
    print(f"[SUCCESS] Member '{name}' added.")


def _issue_book(service: LibraryService, username: str):
    print("\n--- ISSUE BOOK ---")
    isbn = _prompt_nonempty("Book ISBN: ")
    member_id = _prompt_int("Member ID: ")
    txn_id, due_date = service.issue_book(isbn, member_id, username)
    print(f"[SUCCESS] Book issued (Transaction #{txn_id}). Due back by {due_date}.")


def _return_book(service: LibraryService, username: str):
    print("\n--- RETURN BOOK ---")
    txn_id = _prompt_int("Transaction ID: ")
    fine = service.return_book(txn_id, username)
    if fine > 0:
        print(f"[SUCCESS] Book returned. This was overdue -- fine due: Rs. {fine:.2f}")
    else:
        print("[SUCCESS] Book returned on time. No fine charged.")


def _view_overdue(service: LibraryService):
    print("\n--- OVERDUE BOOKS & FINES ---")
    rows = service.list_overdue()
    if not rows:
        print("[INFO] No overdue books right now.")
        return
    from datetime import datetime
    from .services import DATE_FMT, FINE_PER_DAY

    today = datetime.now()
    print(f"{'Txn#':<6}{'Title':<28}{'Member':<18}{'Due Date':<12}{'Days Late':<11}{'Est. Fine (Rs.)':<16}")
    print("-" * 91)
    for r in rows:
        due = datetime.strptime(r["due_date"], DATE_FMT)
        days_late = (today - due).days
        est_fine = max(days_late, 0) * FINE_PER_DAY
        print(
            f"{r['transaction_id']:<6}{r['title']:<28}{r['member_name']:<18}"
            f"{r['due_date']:<12}{days_late:<11}{est_fine:<16.2f}"
        )


# ------------------------------------------------------------------ entry --
def run():
    print("Welcome to the Aptura Library Management System (Advanced Version)")
    db = Database()
    auth = AuthManager(db)
    service = LibraryService(db)

    try:
        while True:
            username = _login_screen(auth)
            if username is None:
                print("Goodbye!")
                break

            print(f"\n[SUCCESS] Welcome, {username}!")
            result = _run_main_menu(service, username)
            if result == "EXIT":
                break
            # result == "LOGOUT" -> loop back to the login screen
    finally:
        db.close()


if __name__ == "__main__":
    run()
