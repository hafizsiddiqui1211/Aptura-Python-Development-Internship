"""
Centralized logging configuration.

Every significant event -- logins (success/failure), books added, issues,
returns, fines charged, and every caught exception -- is written to
`library.log` with a timestamp. This gives the library a full audit trail,
which matters even more once multiple librarians share the same system
(see Question 01 in the accompanying report).
"""

import logging
import os

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "library.log")


def get_logger(name: str = "library_system") -> logging.Logger:
    """Return a module-level logger configured to write to library.log
    (and also echo warnings/errors to the console)."""
    logger = logging.getLogger(name)

    if logger.handlers:
        # Already configured (avoids duplicate handlers on repeated calls)
        return logger

    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.ERROR)  # the CLI already prints its own [ERROR]/[INFO] messages;
    console_handler.setFormatter(formatter)   # only true errors/exceptions also echo here

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger
