"""
Core library business logic: cataloguing, membership, issuing/returning
books, fine calculation, and search/filter.

Concurrency note (ties into Question 01 of the report): `issue_book` and
`return_book` both use a single atomic UPDATE ... WHERE <guard-condition>
statement -- guarded by the row's current state -- rather than a
"SELECT the value, check it in Python, then UPDATE" sequence. That matters
because if two librarians try to issue the last remaining copy of the same
book at nearly the same instant, a SELECT-then-UPDATE pattern could let
both of them "see" 1 copy available and both succeed, leaving
available_copies at -1. Guarding the UPDATE itself
(`WHERE available_copies > 0`) makes the check-and-decrement a single,
indivisible database operation, so only one of the two concurrent
librarians can win.
"""

import sqlite3
from datetime import datetime, timedelta

from .database import Database
from .exceptions import (
    BookNotFoundError,
    BookUnavailableError,
    DuplicateISBNError,
    MemberNotFoundError,
    TransactionError,
    ValidationError,
)
from .logger_setup import get_logger

logger = get_logger(__name__)

LOAN_PERIOD_DAYS = 14
FINE_PER_DAY = 10.0  # PKR per day overdue
DATE_FMT = "%Y-%m-%d"


def _today_str() -> str:
    return datetime.now().strftime(DATE_FMT)


class LibraryService:
    def __init__(self, db: Database):
        self.db = db

    # ============================================================ BOOKS ===
    def add_book(self, isbn: str, title: str, author: str, category: str, total_copies: int):
        isbn, title, author, category = (s.strip() for s in (isbn, title, author, category))
        if not all([isbn, title, author, category]):
            raise ValidationError("ISBN, Title, Author and Category are all required.")
        if total_copies <= 0:
            raise ValidationError("Total copies must be a positive integer.")

        existing = self.db.query("SELECT 1 FROM books WHERE isbn = ?;", (isbn,))
        if existing:
            raise DuplicateISBNError(f"A book with ISBN '{isbn}' already exists.")

        self.db.execute(
            """INSERT INTO books (isbn, title, author, category, total_copies, available_copies)
               VALUES (?, ?, ?, ?, ?, ?);""",
            (isbn, title, author, category, total_copies, total_copies),
        )
        logger.info("Book added: '%s' by %s (ISBN %s, %d copies)", title, author, isbn, total_copies)

    def get_book_by_isbn(self, isbn: str):
        rows = self.db.query("SELECT * FROM books WHERE isbn = ?;", (isbn.strip(),))
        if not rows:
            raise BookNotFoundError(f"No book found with ISBN '{isbn}'.")
        return rows[0]

    def list_all_books(self):
        return self.db.query("SELECT * FROM books ORDER BY title;")

    def search_books(self, keyword: str):
        like = f"%{keyword.strip()}%"
        return self.db.query(
            """SELECT * FROM books
               WHERE title LIKE ? OR author LIKE ? OR category LIKE ? OR isbn LIKE ?
               ORDER BY title;""",
            (like, like, like, like),
        )

    def filter_available_books(self):
        return self.db.query("SELECT * FROM books WHERE available_copies > 0 ORDER BY title;")

    def filter_by_category(self, category: str):
        return self.db.query(
            "SELECT * FROM books WHERE category LIKE ? ORDER BY title;", (f"%{category.strip()}%",)
        )

    # ========================================================== MEMBERS ===
    def add_member(self, name: str, contact: str):
        name = name.strip()
        if not name:
            raise ValidationError("Member name cannot be empty.")
        self.db.execute(
            "INSERT INTO members (name, contact, membership_date) VALUES (?, ?, ?);",
            (name, contact.strip(), _today_str()),
        )
        logger.info("Member added: '%s'", name)

    def get_member(self, member_id: int):
        rows = self.db.query("SELECT * FROM members WHERE member_id = ?;", (member_id,))
        if not rows:
            raise MemberNotFoundError(f"No member found with ID {member_id}.")
        return rows[0]

    def list_all_members(self):
        return self.db.query("SELECT * FROM members ORDER BY name;")

    # ===================================================== ISSUE / RETURN =
    def issue_book(self, isbn: str, member_id: int, librarian_username: str):
        book = self.get_book_by_isbn(isbn)          # raises BookNotFoundError if missing
        self.get_member(member_id)                  # raises MemberNotFoundError if missing

        issue_date = datetime.now()
        due_date = issue_date + timedelta(days=LOAN_PERIOD_DAYS)

        try:
            with self.db.transaction() as cur:
                # Atomic check-and-decrement: only succeeds if a copy is
                # still available AT THE MOMENT OF THE UPDATE, closing the
                # race window described above.
                cur.execute(
                    """UPDATE books SET available_copies = available_copies - 1
                       WHERE book_id = ? AND available_copies > 0;""",
                    (book["book_id"],),
                )
                if cur.rowcount == 0:
                    raise BookUnavailableError(
                        f"'{book['title']}' has no available copies right now."
                    )

                cur.execute(
                    """INSERT INTO transactions
                       (book_id, member_id, issue_date, due_date, status, processed_by)
                       VALUES (?, ?, ?, ?, 'ISSUED', ?);""",
                    (
                        book["book_id"],
                        member_id,
                        issue_date.strftime(DATE_FMT),
                        due_date.strftime(DATE_FMT),
                        librarian_username,
                    ),
                )
                transaction_id = cur.lastrowid
        except BookUnavailableError:
            logger.warning(
                "Issue failed -- '%s' (ISBN %s) unavailable when %s attempted issue.",
                book["title"], isbn, librarian_username,
            )
            raise

        logger.info(
            "Book issued: '%s' -> member #%d by %s (txn #%d, due %s)",
            book["title"], member_id, librarian_username, transaction_id, due_date.strftime(DATE_FMT),
        )
        return transaction_id, due_date.strftime(DATE_FMT)

    def return_book(self, transaction_id: int, librarian_username: str):
        rows = self.db.query(
            "SELECT * FROM transactions WHERE transaction_id = ?;", (transaction_id,)
        )
        if not rows:
            raise TransactionError(f"No transaction found with ID {transaction_id}.")
        txn = rows[0]
        if txn["status"] != "ISSUED":
            raise TransactionError(
                f"Transaction #{transaction_id} was already returned on {txn['return_date']}."
            )

        return_date = datetime.now()
        fine = self.calculate_fine(txn["due_date"], return_date.strftime(DATE_FMT))

        with self.db.transaction() as cur:
            cur.execute(
                """UPDATE transactions
                   SET return_date = ?, fine_amount = ?, status = 'RETURNED'
                   WHERE transaction_id = ? AND status = 'ISSUED';""",
                (return_date.strftime(DATE_FMT), fine, transaction_id),
            )
            if cur.rowcount == 0:
                # Someone else returned it a split second earlier -- bail out cleanly.
                raise TransactionError(
                    f"Transaction #{transaction_id} was already returned by another session."
                )

            cur.execute(
                "UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?;",
                (txn["book_id"],),
            )

        logger.info(
            "Book returned: txn #%d by %s (fine: Rs. %.2f)", transaction_id, librarian_username, fine
        )
        return fine

    @staticmethod
    def calculate_fine(due_date_str: str, return_date_str: str) -> float:
        due = datetime.strptime(due_date_str, DATE_FMT)
        returned = datetime.strptime(return_date_str, DATE_FMT)
        overdue_days = (returned - due).days
        if overdue_days <= 0:
            return 0.0
        return round(overdue_days * FINE_PER_DAY, 2)

    # ============================================================ REPORTS =
    def list_active_transactions(self):
        return self.db.query(
            """SELECT t.transaction_id, b.title, m.name AS member_name,
                      t.issue_date, t.due_date, t.processed_by
               FROM transactions t
               JOIN books b ON b.book_id = t.book_id
               JOIN members m ON m.member_id = t.member_id
               WHERE t.status = 'ISSUED'
               ORDER BY t.due_date;"""
        )

    def list_overdue(self):
        today = _today_str()
        return self.db.query(
            """SELECT t.transaction_id, b.title, m.name AS member_name,
                      t.due_date, t.processed_by
               FROM transactions t
               JOIN books b ON b.book_id = t.book_id
               JOIN members m ON m.member_id = t.member_id
               WHERE t.status = 'ISSUED' AND t.due_date < ?
               ORDER BY t.due_date;""",
            (today,),
        )
