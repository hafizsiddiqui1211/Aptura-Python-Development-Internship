"""
Custom exception hierarchy for the Library Management System.

Using specific, named exceptions (instead of letting raw sqlite3.Error or
generic Exceptions bubble up) lets the CLI layer catch precisely what went
wrong and show the librarian a clear, actionable message -- while everything
still gets logged for auditing.
"""


class LibraryError(Exception):
    """Base class for all application-specific errors in this system."""


# ---------------------------------------------------------------- Auth ----
class AuthenticationError(LibraryError):
    """Raised when a login attempt fails (bad username/password)."""


class UserAlreadyExistsError(LibraryError):
    """Raised when registering a librarian username that is already taken."""


class WeakPasswordError(LibraryError):
    """Raised when a chosen password does not meet the minimum policy."""


# ---------------------------------------------------------------- Books ---
class BookNotFoundError(LibraryError):
    """Raised when a referenced book_id/ISBN does not exist."""


class DuplicateISBNError(LibraryError):
    """Raised when adding a book whose ISBN is already in the catalogue."""


class BookUnavailableError(LibraryError):
    """Raised when trying to issue a book with zero available copies."""


# -------------------------------------------------------------- Members ---
class MemberNotFoundError(LibraryError):
    """Raised when a referenced member_id does not exist."""


# --------------------------------------------------------- Transactions ---
class TransactionError(LibraryError):
    """Raised for invalid issue/return operations (e.g. returning a book
    that was never issued, or that has already been returned)."""


# ----------------------------------------------------------- Validation ---
class ValidationError(LibraryError):
    """Raised when user-supplied input fails basic validation."""
