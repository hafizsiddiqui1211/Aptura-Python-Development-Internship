"""
Database layer (SQLite).

Why SQLite for this deliverable, and how it's used here to already start
addressing the multi-librarian concurrency question (see Question 01 in the
report):

  1. WAL (Write-Ahead Logging) mode is enabled, which lets multiple readers
     work alongside a single writer without blocking each other -- a big
     improvement over SQLite's default rollback-journal mode.
  2. Every write that changes shared state (issuing/returning a book) uses
     an atomic, single-statement UPDATE with a WHERE-guard (see
     services.py) instead of a "read the value, then write a new value"
     pattern -- this closes the race window where two librarians could
     both read "2 copies available" and both issue the last copy.
  3. `busy_timeout` + a small retry wrapper handle the "database is locked"
     errors that occur when two writers *do* collide, instead of letting
     the whole operation crash.

This still isn't a substitute for a real multi-client DBMS (see the
report's full discussion of why MySQL/PostgreSQL is the right call for a
production, networked, multi-librarian deployment) -- but it demonstrates
the same underlying principles at the SQLite scale.
"""

import os
import sqlite3
import time

from .exceptions import LibraryError
from .logger_setup import get_logger

logger = get_logger(__name__)

DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "library.db")

MAX_RETRIES = 5
RETRY_DELAY_SECONDS = 0.2


class Database:
    """Thin wrapper around a SQLite connection: schema setup, a
    retry-on-lock execute helper, and context-managed transactions."""

    def __init__(self, db_path: str = DB_FILE):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, timeout=10, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode = WAL;")
        self.conn.execute("PRAGMA foreign_keys = ON;")
        self.conn.execute("PRAGMA busy_timeout = 5000;")
        self._create_schema()

    # ------------------------------------------------------------------
    def _create_schema(self):
        cur = self.conn.cursor()
        cur.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
                username      TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                salt          TEXT NOT NULL,
                role          TEXT NOT NULL DEFAULT 'librarian',
                created_at    TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS books (
                book_id          INTEGER PRIMARY KEY AUTOINCREMENT,
                isbn             TEXT UNIQUE NOT NULL,
                title            TEXT NOT NULL,
                author           TEXT NOT NULL,
                category         TEXT NOT NULL,
                total_copies     INTEGER NOT NULL,
                available_copies INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS members (
                member_id       INTEGER PRIMARY KEY AUTOINCREMENT,
                name            TEXT NOT NULL,
                contact         TEXT,
                membership_date TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS transactions (
                transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id        INTEGER NOT NULL,
                member_id      INTEGER NOT NULL,
                issue_date     TEXT NOT NULL,
                due_date       TEXT NOT NULL,
                return_date    TEXT,
                fine_amount    REAL NOT NULL DEFAULT 0,
                status         TEXT NOT NULL DEFAULT 'ISSUED',
                processed_by   TEXT NOT NULL,
                FOREIGN KEY (book_id) REFERENCES books (book_id),
                FOREIGN KEY (member_id) REFERENCES members (member_id)
            );
            """
        )
        logger.debug("Schema verified/created at %s", self.db_path)

    # ------------------------------------------------------------------
    def execute(self, query: str, params: tuple = ()):
        """Run a write statement with a small retry loop in case another
        process/thread currently holds the write lock (SQLITE_BUSY)."""
        last_error = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                cur = self.conn.cursor()
                cur.execute(query, params)
                return cur
            except sqlite3.OperationalError as e:
                last_error = e
                if "locked" in str(e).lower() or "busy" in str(e).lower():
                    logger.warning(
                        "DB busy on attempt %d/%d: %s -- retrying", attempt, MAX_RETRIES, e
                    )
                    time.sleep(RETRY_DELAY_SECONDS * attempt)
                    continue
                logger.error("Database operational error: %s", e)
                raise LibraryError(f"Database error: {e}") from e
            except sqlite3.IntegrityError as e:
                logger.error("Database integrity error: %s", e)
                raise  # let callers translate this into a domain-specific exception
        logger.error("Database still locked after %d retries: %s", MAX_RETRIES, last_error)
        raise LibraryError("The database is busy right now. Please try again in a moment.")

    def query(self, query: str, params: tuple = ()):
        """Run a read-only SELECT and return all matching rows."""
        cur = self.conn.cursor()
        cur.execute(query, params)
        return cur.fetchall()

    def transaction(self):
        """Context manager for an explicit atomic transaction
        (BEGIN IMMEDIATE acquires the write lock up front, which avoids
        the classic 'two writers both pass a SELECT check' race)."""
        return _Transaction(self.conn)

    def close(self):
        self.conn.close()


class _Transaction:
    def __init__(self, conn):
        self.conn = conn

    def __enter__(self):
        self.conn.execute("BEGIN IMMEDIATE;")
        return self.conn.cursor()

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            self.conn.execute("COMMIT;")
        else:
            self.conn.execute("ROLLBACK;")
        return False  # never suppress exceptions
