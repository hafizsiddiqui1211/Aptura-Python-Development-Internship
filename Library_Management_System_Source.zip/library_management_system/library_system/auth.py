"""
Librarian authentication.

Passwords are never stored in plain text. Each password is hashed with
PBKDF2-HMAC-SHA256 (100,000 iterations) and a unique, randomly generated
16-byte salt per user, following the same principle a real production
system (see Question 02's security discussion) would use.
"""

import hashlib
import os
from datetime import datetime

from .database import Database
from .exceptions import AuthenticationError, UserAlreadyExistsError, WeakPasswordError
from .logger_setup import get_logger

logger = get_logger(__name__)

PBKDF2_ITERATIONS = 100_000
MIN_PASSWORD_LENGTH = 6


def _hash_password(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS
    ).hex()


class AuthManager:
    def __init__(self, db: Database):
        self.db = db

    def has_any_users(self) -> bool:
        rows = self.db.query("SELECT COUNT(*) AS c FROM users;")
        return rows[0]["c"] > 0

    def register(self, username: str, password: str, role: str = "librarian") -> None:
        username = username.strip()
        if not username:
            raise WeakPasswordError("Username cannot be empty.")
        if len(password) < MIN_PASSWORD_LENGTH:
            raise WeakPasswordError(
                f"Password must be at least {MIN_PASSWORD_LENGTH} characters long."
            )

        existing = self.db.query("SELECT 1 FROM users WHERE username = ?;", (username,))
        if existing:
            raise UserAlreadyExistsError(f"Username '{username}' is already taken.")

        salt = os.urandom(16)
        password_hash = _hash_password(password, salt)

        self.db.execute(
            """INSERT INTO users (username, password_hash, salt, role, created_at)
               VALUES (?, ?, ?, ?, ?);""",
            (username, password_hash, salt.hex(), role, datetime.now().isoformat(timespec="seconds")),
        )
        logger.info("New librarian account registered: '%s' (role=%s)", username, role)

    def login(self, username: str, password: str) -> str:
        """Verify credentials. Returns the username on success, raises
        AuthenticationError on failure."""
        rows = self.db.query(
            "SELECT username, password_hash, salt FROM users WHERE username = ?;",
            (username.strip(),),
        )
        if not rows:
            logger.warning("Failed login attempt for unknown user '%s'.", username)
            raise AuthenticationError("Invalid username or password.")

        row = rows[0]
        salt = bytes.fromhex(row["salt"])
        candidate_hash = _hash_password(password, salt)

        if candidate_hash != row["password_hash"]:
            logger.warning("Failed login attempt for user '%s' (wrong password).", username)
            raise AuthenticationError("Invalid username or password.")

        logger.info("Librarian '%s' logged in successfully.", username)
        return row["username"]
